Mapping Guidelines:
  * Do not add second z levels except when the level is the same size as the main level.
    Its more efficient to use extra space on the map.
  * Do not keep backups, that's what Git is for.
  * Use the maps in the test folder if you need fast startup time. Note that they may be out of date